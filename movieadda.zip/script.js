function sentsms()
{
    alert("Message sent successfully")
}